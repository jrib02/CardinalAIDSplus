def return_zero () :
    return 0